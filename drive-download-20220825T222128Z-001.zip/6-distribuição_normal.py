from scipy.stats import nora

# Conjunto de o